﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using CRUD.Data;
using CRUD.Models;

namespace RegistroPersonas.Pages
{
    public class IndexModel : PageModel
    {
        private readonly ContextDb _context;
        [BindProperty]
        public Persona persona1 {get; set;}

        public IndexModel(ContextDb context)
        {
            _context = context;
        }
        public List<Persona> Personas { get; set;} = new List<Persona>();

        public void OnGet()
        {
            Personas= _context.Personas.ToList();
        }

        public IActionResult OnPost(string NombreCompleto, string TelefonoCasa, string TelefonoCelular, int AnioNacimiento)
        {
            persona1.CreationDate= DateTime.Now;
            _context.Personas.Add(persona1);
            _context.SaveChangesAsync();

            return RedirectToPage();
        }
 public async Task<IActionResult> OnPostEliminarPersonaAsync(int id)
{
    var persona = await _context.Personas.FindAsync(id);
    if (persona == null)
        return RedirectToPage(); // La persona no existe, no se pudo eliminar

    _context.Personas.Remove(persona);
    await _context.SaveChangesAsync();
    return RedirectToPage(); // Persona eliminada exitosamente
}


    
    }
}




