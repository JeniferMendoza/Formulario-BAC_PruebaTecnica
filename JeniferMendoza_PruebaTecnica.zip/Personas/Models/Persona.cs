
namespace CRUD.Models
{
    public class Persona
        {
            public int Id { get; set; }
            public string FullName { get; set; } = string.Empty;
            public string HomePhone { get; set; }  = string.Empty;
            public string CellPhone { get; set; } = string.Empty;
            public int BirthYear { get; set; }
            public DateTime CreationDate { get; set; }
        }

}
    
